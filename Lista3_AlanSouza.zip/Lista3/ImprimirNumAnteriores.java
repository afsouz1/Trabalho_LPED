package Lista3;
import java.util.Scanner;

// LPED - Lista 3 - Atividade 4
// Aluno: Alan Ferreira de Souza
// ADS3 - 2024

public class ImprimirNumAnteriores {
    @SuppressWarnings("static-access")
    public static void main(String[] args) {
        //Ir para menu:
        Lista3.MainCode menu = new MainCode();
        int opt1 = 0;
        //Até aqui

        int num=0;
        Scanner in = new Scanner(System.in);
        System.out.print("\nDigite um número inteiro positivo maior do que zero: ");
        num = in.nextInt();
        if(num>0){
            System.out.println("Número digitado: "+num);
            while(num>0){
                System.out.println("Número anterior: "+(num-1));
                num--;
            }
        System.out.println("\nFim do sistema. Obrigado\n\n");
        }else{
            System.out.println("\nErro 404: Caractere digitado inválido, refaça a operação.\n\n");
        }

         //Ir para menu
         System.out.println("\nDeseja realizar outra atividade?\n (1)Sim; (0)Não\n Opção:  ");
         opt1 = in.nextInt();
         if(opt1==1){
             menu.main(args);
         }else{
             System.out.println("Fim do sistema");
         }//Até aqui
 
        in.close();
    }
}
